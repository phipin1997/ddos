# Tool DDoS
A tool ddos with 56 methods plus can bypass cloudflare,google shield,normal anti ddos,...

# Run On Termux📱,Linux,Window.

# Setup(for termux if install pyroxy and cryptography module failed!)
```shell script
termux-setup-storage
apt update && apt upgrade -y
pkg install python3
pkg install rust
pkg install git
pkg install python-cryptography
pip install setuptools
git clone https://github.com/NamBel12/ToolDDoS.git
cd ToolDDoS
pip install -r requirements.txt
python3 ddos.py
```
